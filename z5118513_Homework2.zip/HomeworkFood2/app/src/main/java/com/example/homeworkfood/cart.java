package com.example.homeworkfood;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class cart extends AppCompatActivity {

    private ArrayList<cart> orderedFood;
    private ArrayList<FoodItems> foodToAdapt;
    private TextView foodDescriptionTitle;
    private TextView cartFoodAmount;
    private ImageView cartImage;
    private String totalCostString;
    private TextView totalCostTextview;
private Button checkoutButton;
private Integer amountInArray = orderedFood.size();
private Integer amountInArrayDivided = amountInArray/3;
private Integer foodNo = 1;

    public void setData(ArrayList<FoodItems> foodToAdapt) {
        this.foodToAdapt = foodToAdapt;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_layout);


        Intent intent = getIntent();
        foodDescriptionTitle = findViewById(R.id.cartFoodDescriptionTitle);
        cartFoodAmount = findViewById(R.id.cartFoodAmount);
        cartImage = findViewById(R.id.cartFoodDescriptionPhoto);
        totalCostTextview = findViewById(R.id.cartTotalCost);
        for (int i=0; i < amountInArrayDivided; i++){
            FoodItems Food = FoodData.getFoodById(foodNo);

            foodDescriptionTitle.setText(Food.getFoodID());
            totalCostString = Double.toString(Food.getPrice());
            totalCostTextview.setText(totalCostString);
            cartFoodAmount.setText(Food.getDescription());
            cartImage.setImageResource(Food.getImageDrawableId());

        }

    }


}