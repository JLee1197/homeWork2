package com.example.homeworkfood;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class FoodData {

    public static FoodItems getFoodById(int FoodID) {
        return foods.get(FoodID);
    }

    public static ArrayList<FoodItems> getAllFoods() {
        return new ArrayList<FoodItems>((List) Arrays.asList(foods.values().toArray()));

    }

    private static final HashMap<Integer, FoodItems> foods = new HashMap<>();

    static {
        foods.put(1, new FoodItems(
                1,
                "Big Mac",
                10.20,
                "Big Mac Burger made from prime double prime steak meat weow.",
                R.drawable.big_mac
        ));
        foods.put(2, new FoodItems(
                2,
                "Chicken Burger",
                9.30,
                "Chicken weow.",
                R.drawable.chicken_burger

        ));
        foods.put(3, new FoodItems(
                3,
                "Milkshake",
                5.40,
                "Filled with cream and milk and deliciousness",
                R.drawable.milkshake
        ));
        foods.put(4, new FoodItems(
                4,
                "Water",
                3.20,
                "A refreshing bottle of water.",
                R.drawable.water
        ));
        foods.put(5, new FoodItems(
                5,
                "Fresh Apples",
                8.30,
                "A healthy snack for kids.",

                R.drawable.apples
        ));
        foods.put(6, new FoodItems(
                6,
                "6 pack Nuggets",
                11.20,
                "A delicious packet of 100% pure, free range and non gmo chicken breast nugget.",

                R.drawable.chicken_nuggets
        ));
        foods.put(7, new FoodItems(
                7,
                "Caesar Wrap",
                11.50,
                "A delicious wrap with fresh chicken, boiled eggs and lettuce.",
                R.drawable.caesar_wrap
        ));
        foods.put(8, new FoodItems(
                8,
                "Fillet o Fish",
                13.50,
                "Fresh anaconda fish from the jungles of the amazon straight to maccas",
                R.drawable.filletofish
        ));
        foods.put(9, new FoodItems(

                9,
                "Shakeshack Burger",
                20.30,
                "Fresh burger stolen straight from the shakeshack store next door at an increased price for you to enjoy",
                R.drawable.shakeshack
        ));
        foods.put(10, new FoodItems(
                10,
                "Apple Pie",
                6.50,
                "Freshly baked apple pie, made from fresh home grown Australian apples",

                R.drawable.apple_pie
        ));
        foods.put(11, new FoodItems(
                11,
                "Pineapple Pie",
                7.50,
                "Fresh pineapples within the famous apple pie, taste the sweetness now",

                R.drawable.pineapple
        ));
        foods.put(12, new FoodItems(
                12,
                "Quarter Pounder",
                14.20,
                "Pure 100% Australian grown beef in our famous buttery bread.",

                R.drawable.quarter_pounder
        ));
        foods.put(13, new FoodItems(
                13,
                "Mega Mac",
                15.80,
                "If you want double the big mac, then get the mega mac for double the meat and double the value.",

                R.drawable.mega_mac
        ));
        foods.put(14, new FoodItems(
                14,
                "Hash Brown",
                1.50,
                "freshly baked potato",

                R.drawable.hashbrown
        ));
        foods.put(15, new FoodItems(
                15,
                "Sundae",
                7.20,
                "Fresh from the cow milk from the mountains of italy.",

                R.drawable.sundae
        ));


    }

}
