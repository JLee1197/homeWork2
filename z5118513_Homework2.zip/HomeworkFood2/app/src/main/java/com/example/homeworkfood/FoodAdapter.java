package com.example.homeworkfood;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {

    private ArrayList<FoodItems> foodToAdapt;

    public void setData(ArrayList<FoodItems> foodToAdapt) {
        this.foodToAdapt = foodToAdapt;
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.food_item, parent, false);
        FoodViewHolder foodViewHolder = new FoodViewHolder(view);
        return foodViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        final FoodItems foodAtPosition = foodToAdapt.get(position);

        holder.FoodName.setText(foodAtPosition.getName());
        holder.FoodCost.setText(foodAtPosition.getPriceAsString());

        holder.foodImage.setImageResource(foodAtPosition.getImageDrawableId());

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();

                Intent intent = new Intent(context, FoodDescriptionActivity.class);
                intent.putExtra("FoodID", foodAtPosition.getFoodID());
                context.startActivity(intent);
            }
        });





    }

    @Override
    public int getItemCount() {
        return foodToAdapt.size();
    }
    public class FoodViewHolder extends RecyclerView.ViewHolder {
        public View view;
        public TextView FoodName;
        public TextView FoodDescription;
        public TextView FoodCost;
        public ImageView foodImage;

        public FoodViewHolder(View v) {
            super(v);
            view = v;
            FoodName = v.findViewById(R.id.cartFoodDescriptionTitle);
            FoodDescription = v.findViewById(R.id.foodDescriptionDetail);
            FoodCost = v.findViewById(R.id.cartFoodAmount);
            foodImage = v.findViewById(R.id.cartFoodDescriptionPhoto);
        }
    }


}