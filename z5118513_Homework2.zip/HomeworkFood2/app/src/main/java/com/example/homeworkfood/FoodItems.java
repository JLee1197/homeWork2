package com.example.homeworkfood;

public class FoodItems {
    private int FoodID;
    private String Name;
    private Double Price;
    private String Description;
    private int imageDrawableId;
    private String priceAsString;

    public FoodItems(int FoodID, String Name, Double Price, String Description, int imageDrawableId) {
        this.FoodID = FoodID;
        this.Price = Price;
        this.Description = Description;
        this.Name = Name;
        this.imageDrawableId = imageDrawableId;
    }

    public int getFoodID() {
        return FoodID;
    }

    public void setFoodID(int FoodID) {
        this.FoodID = FoodID;
    }

    public  String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public  Double getPrice() {
        return Price;
    }

    public String getPriceAsString(){
        priceAsString = Double.toString((Price));
   return priceAsString;
    }

    public void setPrice(Double Price) {
        this.Price = Price;
    }

    public  String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public  int getImageDrawableId() {
        return imageDrawableId;
    }

    public void setImageDrawableId(int imageDrawableId) {
        this.imageDrawableId = imageDrawableId;
    }
}
