package com.example.homeworkfood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class FoodDescriptionActivity extends AppCompatActivity {


    private TextView foodTitleTextView;
    private ImageView foodPhoto;
    private TextView foodDescriptionTextView ;
    private TextView foodCostTextView;
    private String foodCostToString;
    private Integer quantity = 0;
    private TextView foodAmount;
    private Double currentFoodPrice;
    private Double totalFoodCost ;
    private String totalFoodCostString;
    private Button minusButton = findViewById(R.id.minusButton);
    private Button plusButton = findViewById(R.id.plusSign);
    private Button cartButton = findViewById(R.id.cartButton);
    private TextView foodDescriptionTotalCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_description);


        Intent intent = getIntent();


        int FoodID = intent.getIntExtra("FoodID", 0);


        FoodItems food = FoodData.getFoodById(FoodID);
        currentFoodPrice = food.getPrice();
        totalFoodCost = 0.00;
        foodTitleTextView = findViewById(R.id.cartFoodDescriptionTitle);
        foodDescriptionTextView = findViewById(R.id.foodDescriptionDetail);
        foodCostTextView = findViewById(R.id.cartFoodAmount);
        foodPhoto = findViewById(R.id.cartFoodDescriptionPhoto);
        foodDescriptionTotalCost = findViewById(R.id.foodDescriptionTotalCost);
        foodAmount = findViewById(R.id.foodAmount);






        foodTitleTextView.setText(food.getName());
        foodCostToString = Double.toString((food.getPrice()));
        foodCostTextView.setText(foodCostToString);
        foodDescriptionTextView.setText(food.getDescription());
        foodDescriptionTotalCost.setText(totalFoodCostString);
        foodAmount.setText(quantity);



        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (quantity > 0){
                    quantity = quantity - 1;
                    foodAmount.setText(quantity);
                    totalFoodCost = totalFoodCost - currentFoodPrice;
                    totalFoodCostString = Double.toString(totalFoodCost);
                    foodDescriptionTotalCost.setText(totalFoodCostString);
                }else
                    quantity = 0;
                foodAmount.setText(quantity);

            }

        });
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity = quantity + 1;
                foodAmount.setText(quantity);
                totalFoodCost = totalFoodCost + currentFoodPrice;
                totalFoodCostString = Double.toString(totalFoodCost);
                foodDescriptionTotalCost.setText(totalFoodCostString);
            }

        });
        cartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity = 0;

            }

        });

    }

}
